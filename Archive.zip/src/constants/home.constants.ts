export const tipsAndTutorialsCards = [
  {
    title: 'An abstract is a brief summary of a research.',
    date: 'Jul 28, 2022',
    backgroundImage: 'url(/assets/images/tips-tutorials.png)',
  },
  {
    title: 'An abstract is a brief summary of a research.',
    date: 'Jul 28, 2022',
    backgroundImage: 'url(/assets/images/tips-tutorials.png)',
  },
  {
    title: 'An abstract is a brief summary of a research.',
    date: 'Jul 28, 2022',
    backgroundImage: 'url(/assets/images/tips-tutorials.png)',
  },
  {
    title: 'An abstract is a brief summary of a research.',
    date: 'Jul 28, 2022',
    backgroundImage: 'url(/assets/images/tips-tutorials.png)',
  },
];

export const upcomingNftProjects = [
  {
    title: 'Bless the Fallout Sadness',
    time: '00 : 02 : 06',
    backgroundImage: 'url(/assets/images/upcoming-nft-projects-card.png)',
    subTitle: 'Abilities or he perfectly.',
  },
  {
    title: 'Bless the Fallout Sadness',
    time: '00 : 02 : 06',
    backgroundImage: 'url(/assets/images/upcoming-nft-projects-card.png)',
    subTitle: 'Abilities or he perfectly.',
  },
  {
    title: 'Bless the Fallout Sadness',
    time: '00 : 02 : 06',
    backgroundImage: 'url(/assets/images/upcoming-nft-projects-card.png)',
    subTitle: 'Abilities or he perfectly.',
  },
  {
    title: 'Bless the Fallout Sadness',
    time: '00 : 02 : 06',
    backgroundImage: 'url(/assets/images/upcoming-nft-projects-card.png)',
    subTitle: 'Abilities or he perfectly.',
  },
];

export const events = [
  {
    title: 'Annual Meeting of the NTF Community',
    backgroundImage: 'url(/assets/images/events-card.png)',
    date: 'Aug 29, 17:00',
  },
  {
    title: 'Annual Meeting of the NTF Community',
    backgroundImage: 'url(/assets/images/events-card.png)',
    date: 'Aug 29, 17:00',
  },
  {
    title: 'Annual Meeting of the NTF Community',
    backgroundImage: 'url(/assets/images/events-card.png)',
    date: 'Aug 29, 17:00',
  },
  {
    title: 'Annual Meeting of the NTF Community',
    backgroundImage: 'url(/assets/images/events-card.png)',
    date: 'Aug 29, 17:00',
  },
];
