export const WEBSOCKET_URL = 'ws://localhost:8000';
export const API_URL = 'https://napa-backend-staging.napasociety.io';
