import React from 'react';
import Image from 'next/image';
import Select from 'react-select';
import 'bootstrap-daterangepicker/daterangepicker.css';
import DateRangePicker from 'react-bootstrap-daterangepicker';
import 'bootstrap/dist/css/bootstrap.css';
import moment from 'moment';
import styles from './ValuatorTabTwo.module.scss';
import Link from 'next/link';

export default function FeedTab() {
    const options = [
        { value: 'chocolate', label: 'Chocolate' },
        { value: 'strawberry', label: 'Strawberry' },
        { value: 'vanilla', label: 'Vanilla' },
      ];
      const optionstow = [
        { value: '1', label: 'Price 20 MRP' },
        { value: '2', label: 'Price 250 MRP' },
        { value: '3', label: 'Price 50 MRP' },
      ];
      const optionsthree = [
        { value: '1', label: '20%' },
        { value: '2', label: '50%' },
        { value: '3', label: '100%' },
      ];
      const optionsfour = [
        { value: 'chocolate', label: '4h 32 min' },
        { value: 'strawberry', label: '4h 32 min' },
        { value: 'vanilla', label: '4h 32 min' },
      ];
      const [active, setActive] = React.useState(false);
      const handleClick = () => {
        setActive(!active);
      };
  return (
    <>
        <div className={styles.valtrTabTwoHed}>
            
        </div>
       
    </>
  )
}
