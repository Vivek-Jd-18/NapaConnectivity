export const supportedChainHexTest = "0x5"; //Testnet
export const supportedChainHexMain = "0x1"; //Mainnet 
export const MarketPlaceAddress = "0x7FfA9f17BB43474c20e30b65559807B3013A6eb7"
export const NapaNFTAddress = "0xe771eF6bFbCFff122955734CC7cEF15Ba5B962AE"