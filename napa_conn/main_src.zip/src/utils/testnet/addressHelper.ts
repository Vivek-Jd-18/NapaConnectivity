export const nftAddress = "0xEF32F87f63b35061823e7f9BF1F8acEaBb6a1d79"
export const NapaTokenAddress = "0xAD3301ED384756216C0013c8CC4bbf4Cc800521f"
export const UsdtTokenAddress = "0x7c34236484A48258d4A8B3D446D88a491b68e207"
